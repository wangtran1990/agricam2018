<?php
/**
 * Locale API
 *
 * @package WordPress
 * @subpackage i18n
 * @since 1.2.0
 */

_deprecated_file( basename( __FILE__ ), '4.7.0' );
